# Automating Standard Laptop Orders with Flow Designer

## ServiceNow Project

This project demonstrates a standard laptop ordering workflow automated using ServiceNow Flow Designer.

## Included Screenshots

1. Catalog Items
2. Standard Laptop catalog item
3. Flow Designer
4. Catalog Task
5. Requested Item (RITM)
6. Order Status

## Platform
- ServiceNow Developer Instance
- Service Catalog
- Flow Designer

## Workflow
Employee submits Standard Laptop request -> Flow Designer triggers -> Catalog Task is created -> Requested Item is processed -> Order status is displayed.
